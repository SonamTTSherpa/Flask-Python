from flask import Flask, render_template  
app = Flask(__name__)                     
    
@app.route('/')
def play():
  print(play)
  return render_template('play.html')

@app.route('/play/<times>')                           
def box(times):
  print(times)
  return render_template('play2.html',times=int(times))

@app.route('/play/<times>/<color>')                           
def boxWcolors(times, color):
  print(times)
  return render_template('play3.html',times=int(times), color=str(color))

if __name__=="__main__":
  app.run(debug=True)   
