from flask import Flask, render_template
app = Flask(__name__)                     

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/<times>')                           
def box(times):
    times = int(times)
    print(times)
    return render_template('index1.html',times=int(times))

@app.route('/<t1>/<t2>')                           
def box1(t1, t2):
    t1 = int(t1)
    t2 = int(t2)
    print(t1, t2)
    return render_template('index2.html',t1=int(t1),t2=int(t2))



if __name__=="__main__":
    app.run(debug=True)   