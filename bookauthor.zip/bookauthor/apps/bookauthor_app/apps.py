from django.apps import AppConfig


class BookauthorAppConfig(AppConfig):
    name = 'bookauthor_app'
