from django.db import models
import datetime
    
class Movie(models.Model):
    title = models.CharField(max_length=45)
    description = models.TextField()
    release_date = models.DateTimeField(default=datetime.datetime.now())
    duration = models.IntegerField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class Actor(models.Model):
    name = models.TextField()
    age = models.IntegerField()
    role = models.TextField()