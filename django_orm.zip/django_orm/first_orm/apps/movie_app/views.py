from django.shortcuts import render
from .models import Movie
from .models import Actor

def index(request):
    context = {
        "all_the_movies": Movie.objects.all()
    }
    return render(request, "movie_app/index.html", context)

def actor(request):
    context = {
        "actors": Actor.objects.all()
    }
    return render(request, "movie_app/actor.html", context)
