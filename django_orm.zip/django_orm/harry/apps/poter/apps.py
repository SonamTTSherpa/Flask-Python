from django.apps import AppConfig


class PoterConfig(AppConfig):
    name = 'poter'
