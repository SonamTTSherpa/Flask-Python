from django.shortcuts import render
from .models import Book
from .models import Author

def index(request):
    context = {
        "all_the_book": Book.objects.all()
        
    }
    return render(request, "book_author_app/index.html", context)

