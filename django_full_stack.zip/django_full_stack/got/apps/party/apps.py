from django.apps import AppConfig


class PartyConfig(AppConfig):
    name = 'party'
