from django.apps import AppConfig


class RegisterLoginConfig(AppConfig):
    name = 'register_login'
