from django.apps import AppConfig


class NinjagoldAppConfig(AppConfig):
    name = 'ninjaGold_app'
