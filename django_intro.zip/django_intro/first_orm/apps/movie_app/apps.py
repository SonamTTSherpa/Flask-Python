from django.apps import AppConfig


class MovieAppConfig(AppConfig):
    name = 'movie_app'
