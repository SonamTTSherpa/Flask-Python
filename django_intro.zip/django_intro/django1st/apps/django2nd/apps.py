from django.apps import AppConfig


class Django2NdConfig(AppConfig):
    name = 'django2nd'
